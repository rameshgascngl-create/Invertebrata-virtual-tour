# Launcher icon generation

Canonical master: `launcher_assets/master/invertebrata_icon_master.png`

Expected master SHA-256: `dbd00a8d0e8ce09574c9c730b5fb4fa0049b3470171204c6db4712184bb54f7e`

Generated launcher resources:

- legacy density PNGs: mdpi 48 px, hdpi 72 px, xhdpi 96 px, xxhdpi 144 px, xxxhdpi 192 px;
- matching circular legacy icons at each density;
- adaptive icon foreground: 432 px source crop in `drawable-nodpi/ic_launcher_foreground.png`;
- adaptive background: `@color/launcher_background` (`#063A35`);
- adaptive icon XMLs in `mipmap-anydpi-v26`.

No academic runtime file is modified by the icon-generation step.
