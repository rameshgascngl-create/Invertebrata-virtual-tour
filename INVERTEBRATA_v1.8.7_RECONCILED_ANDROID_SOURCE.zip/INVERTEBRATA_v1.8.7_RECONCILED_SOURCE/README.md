# INVERTEBRATA Android — Reconciled v1.8.7 Source

Canonical Android identity:

- applicationId / namespace: `com.gasczoology.invertebratelab`
- versionName: `1.8.7`
- versionCode: `18700`
- minSdk: `24`
- targetSdk / compileSdk: `36`

## Source layout

- `app/` — native Android WebView shell and Android resources.
- `academic_payload/index.html` — immutable canonical academic payload.
- `app/src/main/assets/www/index.html` — byte-identical build-time copy of the canonical payload.
- `launcher_assets/master/` — reconciled master launcher artwork.
- `app/src/main/res/mipmap-*` + `drawable-nodpi/` — generated Android launcher resources.
- `provenance/` — source provenance and SHA-256 manifests.
- `qa/` — static QA report.
- `gradle/wrapper/GRADLE_WRAPPER_RESTORATION_BLOCKED.md` — explicit wrapper status.

## Academic payload lock

Expected SHA-256:

`25220886837b724f781612f66ae5f8fd4a983ca644559c4871aff91b479e24b7`

The build-time asset must remain byte-for-byte identical to `academic_payload/index.html`.

## Build boundary

This package is **source-only**. Android compilation, APK installation, release signing, and physical-device QA were deliberately not performed in this reconciliation environment.

Before any genuine build, restore the official Gradle 8.14.3 wrapper, provision JDK 17, Android SDK Platform 36 / Build Tools 36.0.0, Google Maven, Maven Central, adb/device tooling and the secure release keystore. Then run:

`./gradlew --no-daemon clean lint test assembleDebug assembleRelease bundleRelease --stacktrace`
