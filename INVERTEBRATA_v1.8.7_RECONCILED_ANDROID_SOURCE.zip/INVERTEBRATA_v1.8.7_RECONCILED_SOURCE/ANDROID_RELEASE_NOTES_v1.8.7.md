# INVERTEBRATA v1.8.7 — Source Reconciliation Notes

This source tree reconciles the canonical Android identity, immutable academic payload and launcher resources without compiling or repackaging an APK.

Canonical identity: `com.gasczoology.invertebratelab` / `1.8.7` / `18700`.

Academic payload SHA-256: `25220886837b724f781612f66ae5f8fd4a983ca644559c4871aff91b479e24b7`.

Launcher master SHA-256: `dbd00a8d0e8ce09574c9c730b5fb4fa0049b3470171204c6db4712184bb54f7e`.

Release state: **SOURCE RECONCILED — BUILD/INSTALL/SIGNING/DEVICE QA NOT TESTED**.
