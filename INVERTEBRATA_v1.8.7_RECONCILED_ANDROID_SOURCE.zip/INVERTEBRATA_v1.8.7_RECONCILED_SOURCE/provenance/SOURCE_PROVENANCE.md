# Source provenance — INVERTEBRATA v1.8.7

## Canonical academic payload

- file: `academic_payload/index.html`
- SHA-256: `25220886837b724f781612f66ae5f8fd4a983ca644559c4871aff91b479e24b7`
- integration rule: `app/src/main/assets/www/index.html` must remain byte-identical.

The payload was preserved without modification during the Android identity and icon-resource reconciliation. The unverified `db9e9009…` runtime and claimed 129-MCQ material were not incorporated.

## Launcher artwork

- master: `launcher_assets/master/invertebrata_icon_master.png`
- SHA-256: `dbd00a8d0e8ce09574c9c730b5fb4fa0049b3470171204c6db4712184bb54f7e`

Density and adaptive resources were deterministically generated from this master without editing the academic payload.

## Android shell ancestry

The Android shell was reconciled from the previously exported v1.8.3 Android source archive:

- source archive SHA-256: `6c3daf52ba5956cebe8d3a45909c824814be8cfb611b3cc1835cd98948cd5eaf`

Only source/configuration/resources were reconciled. No APK was patched, repacked, signed or produced in this environment.

## Gradle wrapper

**GRADLE WRAPPER RESTORATION: BLOCKED**

Target distribution: official `gradle-8.14.3-bin.zip`. No wrapper JAR or launcher script was copied from another project.
