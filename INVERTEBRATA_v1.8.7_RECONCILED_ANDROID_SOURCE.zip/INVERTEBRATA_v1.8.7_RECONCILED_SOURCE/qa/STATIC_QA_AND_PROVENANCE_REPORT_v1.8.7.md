# INVERTEBRATA v1.8.7 — Static QA & Provenance Report

**Scope:** reconciled Android source only. No Android compilation, APK generation, signing, installation or device execution was performed in this environment.

## Canonical identity

- applicationId / namespace: `com.gasczoology.invertebratelab`
- versionName: `1.8.7`
- versionCode: `18700`
- minSdk: `24`
- targetSdk / compileSdk: `36`
- Android Gradle Plugin declared by source: `8.13.0`
- intended Gradle distribution: official `gradle-8.14.3-bin.zip`

## Static validation

| Gate | Result | Evidence |
|---|---|---|
| CANONICAL PAYLOAD HASH | **PASS** | `academic_payload/index.html` = `25220886837b724f781612f66ae5f8fd4a983ca644559c4871aff91b479e24b7` |
| 43-CHAPTER PAYLOAD PRESENT | **PASS** | `window.SYLLABUS_CHAPTERS_DATA` parses to exactly 43 chapter records |
| APPLICATION ID | **PASS** | namespace/applicationId = `com.gasczoology.invertebratelab` |
| VERSION NAME | **PASS** | `1.8.7` |
| VERSION CODE | **PASS** | `18700` |
| OLD PACKAGE IDENTIFIERS REMOVED | **PASS** | no `com.gasczoology.invertebratafull184`, `versionCode 184`, or `versionName 1.8.4` in active source/configuration |
| NEW ICON RESOURCES | **PASS** | canonical master hash verified; legacy density, round and adaptive resources generated |
| MANIFEST CONSISTENCY | **PASS** | launcher activity, icon/roundIcon references and no INTERNET permission verified statically |
| LOCAL/OFFLINE ASSET REFERENCES | **PASS** | WebViewAssetLoader uses the local `appassets.androidplatform.net` origin; file/content access disabled |
| EXTERNAL WEB DEPENDENCY CHECK | **PASS** | no external runtime endpoint found; only SVG namespace/local appassets origin allowed |
| SOURCE PROVENANCE | **PASS** | academic payload and launcher master both match approved SHA-256 values |

## Identity reconciliation details

- Java package: `com.gasczoology.invertebratelab`.
- ProGuard/R8 keep rule targets the same canonical `MainActivity` package.
- Manifest uses relative `.MainActivity`, resolving against the canonical namespace/application ID.
- No custom provider authority is declared in the application manifest.
- Debug source no longer applies an alternate application ID suffix; both build variants inherit the single canonical application ID.
- Future CI metadata is labelled v1.8.7 and is fail-closed until the official Gradle 8.14.3 wrapper is restored.

## Academic payload lock

The approved academic payload is copied into two locations:

1. provenance source: `academic_payload/index.html`;
2. Android build asset: `app/src/main/assets/www/index.html`.

They are byte-for-byte identical and have the same approved SHA-256. No academic-content edit was made during identity, icon, manifest, CI or provenance reconciliation.

The unverified `db9e9009…` runtime and claimed 129-MCQ material were **not incorporated**.

## Launcher resources

Approved master SHA-256:

`dbd00a8d0e8ce09574c9c730b5fb4fa0049b3470171204c6db4712184bb54f7e`

Prepared source resources:

- `mipmap-mdpi` 48 px legacy + round icon;
- `mipmap-hdpi` 72 px legacy + round icon;
- `mipmap-xhdpi` 96 px legacy + round icon;
- `mipmap-xxhdpi` 144 px legacy + round icon;
- `mipmap-xxxhdpi` 192 px legacy + round icon;
- `drawable-nodpi/ic_launcher_foreground.png` adaptive foreground;
- `mipmap-anydpi-v26/ic_launcher.xml` adaptive configuration;
- `mipmap-anydpi-v26/ic_launcher_round.xml` adaptive round configuration;
- `@color/launcher_background` = `#063A35`.

The previous launcher vectors were removed so that obsolete/default artwork cannot override the reconciled icon.

## Gradle wrapper status

**GRADLE WRAPPER RESTORATION: BLOCKED**

No wrapper JAR or launcher script was copied from another project. When a suitable environment becomes available, generate/verify the standard wrapper from the official Gradle 8.14.3 distribution and record its checksums/provenance before building.

## Explicitly untested release gates

| Gate | Status |
|---|---|
| ANDROID BUILD | **NOT TESTED** |
| APK INSTALLATION | **NOT TESTED** |
| RELEASE SIGNING | **NOT TESTED** |
| DEVICE QA | **NOT TESTED** |
| APK ALIGNMENT / SIGNATURE VERIFICATION | **NOT TESTED** |
| UPGRADE INSTALLATION | **NOT TESTED** |
| AIRPLANE-MODE FIRST LAUNCH | **NOT TESTED** |

These gates must not be reported as PASS until a genuine Android build/device environment is used.

## Eventual genuine-build prerequisites

Provision JDK 17 compatible with AGP 8.13, Android SDK Platform 36, Build Tools 36.0.0, official Gradle 8.14.3 wrapper, functional Google Maven/Maven Central, adb, an emulator or physical device, and the secure release keystore. Then execute:

```bash
./gradlew --no-daemon clean lint test assembleDebug assembleRelease bundleRelease --stacktrace
```

Afterward perform APK/AAB binary inspection, alignment/signature verification, clean install, compatible upgrade install and representative installed-app QA before release classification.
