# Keep the Activity name referenced by AndroidManifest.xml.
-keep class com.gasczoology.invertebratelab.MainActivity { *; }
