#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, re, sys

ROOT = Path(__file__).resolve().parents[1]
PAYLOAD_HASH = '25220886837b724f781612f66ae5f8fd4a983ca644559c4871aff91b479e24b7'
ICON_HASH = 'dbd00a8d0e8ce09574c9c730b5fb4fa0049b3470171204c6db4712184bb54f7e'
APP_ID = 'com.gasczoology.invertebratelab'
VERSION_NAME = '1.8.7'
VERSION_CODE = '18700'
FORBIDDEN = ['com.gasczoology.invertebratafull184', 'versionCode 184', "versionName '1.8.4'", 'versionName "1.8.4"']

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def check(name, ok, detail=''):
    status='PASS' if ok else 'FAIL'
    print(f'{name}: {status}' + (f' — {detail}' if detail else ''))
    return ok

results=[]
payload = ROOT/'academic_payload/index.html'
asset = ROOT/'app/src/main/assets/www/index.html'
master = ROOT/'launcher_assets/master/invertebrata_icon_master.png'
results.append(check('CANONICAL PAYLOAD HASH', payload.exists() and sha(payload)==PAYLOAD_HASH, sha(payload) if payload.exists() else 'missing'))
results.append(check('ANDROID ASSET PAYLOAD HASH', asset.exists() and sha(asset)==PAYLOAD_HASH, sha(asset) if asset.exists() else 'missing'))
results.append(check('PAYLOAD BYTE IDENTITY', payload.exists() and asset.exists() and payload.read_bytes()==asset.read_bytes()))

chapters=[]
if payload.exists():
    text=payload.read_text(encoding='utf-8')
    m=re.search(r'window\.SYLLABUS_CHAPTERS_DATA\s*=\s*(\[.*?\]);\s*\n', text, re.S)
    if m:
        try: chapters=json.loads(m.group(1))
        except Exception: chapters=[]
results.append(check('43-CHAPTER PAYLOAD PRESENT', len(chapters)==43, f'count={len(chapters)}'))

bg=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
results.append(check('APPLICATION ID', f"applicationId '{APP_ID}'" in bg and f"namespace '{APP_ID}'" in bg))
results.append(check('VERSION NAME', f"versionName '{VERSION_NAME}'" in bg))
results.append(check('VERSION CODE', f'versionCode {VERSION_CODE}' in bg))

stale=[]
active_paths=[ROOT/'app', ROOT/'.github', ROOT/'build.gradle', ROOT/'settings.gradle', ROOT/'gradle.properties']
files=[]
for base in active_paths:
    if base.is_file(): files.append(base)
    elif base.exists(): files.extend(x for x in base.rglob('*') if x.is_file())
for p in files:
    if p.suffix.lower() in {'.png','.jpg','.jpeg','.zip','.jar','.apk','.aab'}: continue
    try: txt=p.read_text(encoding='utf-8')
    except Exception: continue
    for token in FORBIDDEN:
        if token in txt: stale.append(f'{p.relative_to(ROOT)} :: {token}')
results.append(check('OLD PACKAGE IDENTIFIERS REMOVED', not stale, '; '.join(stale[:6])))

icon_files=[
    'app/src/main/res/drawable-nodpi/ic_launcher_foreground.png',
    'app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
    'app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml',
]
for d in ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']:
    icon_files += [f'app/src/main/res/mipmap-{d}/ic_launcher.png', f'app/src/main/res/mipmap-{d}/ic_launcher_round.png']
icons_ok=all((ROOT/x).is_file() for x in icon_files) and master.is_file() and sha(master)==ICON_HASH
results.append(check('NEW ICON RESOURCES', icons_ok, f'master={sha(master) if master.exists() else "missing"}'))

manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
manifest_ok='android:icon="@mipmap/ic_launcher"' in manifest and 'android:roundIcon="@mipmap/ic_launcher_round"' in manifest and 'android:name=".MainActivity"' in manifest and 'android.permission.INTERNET' not in manifest
results.append(check('MANIFEST CONSISTENCY', manifest_ok))

main=(ROOT/'app/src/main/java/com/gasczoology/invertebratelab/MainActivity.java').read_text(encoding='utf-8')
local_ok='https://appassets.androidplatform.net' in main and '/assets/www/index.html' in main and 'WebViewAssetLoader' in main and 'setAllowFileAccess(false)' in main and 'setAllowContentAccess(false)' in main
results.append(check('LOCAL/OFFLINE ASSET REFERENCES', local_ok))

urls=[]
if payload.exists():
    text=payload.read_text(encoding='utf-8')
    urls=sorted(set(re.findall(r'https?://[^\s\"\'<>\\]+', text)))
allowed=lambda u: u.startswith('http://www.w3.org/2000/svg') or u.startswith('https://appassets.androidplatform.net')
external=[u for u in urls if not allowed(u)]
results.append(check('EXTERNAL WEB DEPENDENCY CHECK', not external, ', '.join(external[:5]) if external else 'no external runtime endpoint'))

prov_ok=payload.exists() and master.exists() and sha(payload)==PAYLOAD_HASH and sha(master)==ICON_HASH
results.append(check('SOURCE PROVENANCE', prov_ok))

print('ANDROID BUILD: NOT TESTED')
print('APK INSTALLATION: NOT TESTED')
print('RELEASE SIGNING: NOT TESTED')
print('DEVICE QA: NOT TESTED')

sys.exit(0 if all(results) else 1)
