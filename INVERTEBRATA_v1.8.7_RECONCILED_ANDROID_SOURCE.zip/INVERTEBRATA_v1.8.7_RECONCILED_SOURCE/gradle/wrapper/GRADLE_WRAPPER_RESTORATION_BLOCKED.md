# GRADLE WRAPPER RESTORATION: BLOCKED

The canonical project targets **Gradle 8.14.3** and the official distribution:

`https://services.gradle.org/distributions/gradle-8.14.3-bin.zip`

No `gradlew`, `gradlew.bat`, `gradle-wrapper.jar`, or `gradle-wrapper.properties` has been fabricated or copied from another project in this reconciliation environment.

When a suitable Android build environment is available, generate the wrapper from the **official Gradle 8.14.3 distribution**, record checksums/provenance, and commit the resulting standard wrapper files before running the Android build.
